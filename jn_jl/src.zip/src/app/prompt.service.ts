import { Injectable } from '@angular/core';
import { type Mode } from './models';

export interface PromptOptions {
  mode: Mode;
  task: string;
  criteria: string[];
  priority: string;
  storyPoints: string;
  component: string;
  language: string;
  jiraText: string;
  codeText: string;
  codeLanguage: string;
}

@Injectable({ providedIn: 'root' })
export class PromptService {
  build(opts: PromptOptions): string {
    const ac = opts.criteria.length
      ? opts.criteria.map((c, i) => `${i + 1}. ${c}`).join('\n')
      : 'None provided';

    switch (opts.mode) {
      case 'evaluate':
        return this.evaluatePrompt(opts.task, ac);
      case 'jira':
        return this.jiraPrompt(opts, ac);
      case 'code':
        return this.codeGenPrompt(opts.task, ac, opts.language);
      case 'analyze-jira':
        return this.analyzeJiraPrompt(opts.jiraText);
      case 'analyze-code':
        return this.analyzeCodePrompt(opts.codeText, opts.codeLanguage);
    }
  }

  private evaluatePrompt(task: string, ac: string): string {
    return `You are a senior software engineer performing a task evaluation.

## Task Description
${task}

## Acceptance Criteria
${ac}

Provide a structured evaluation report covering:
1. **Task Complexity** — Simple / Moderate / Complex / Very Complex, with reasoning
2. **Effort Estimate** — Story points and time estimate (best/worst case in developer days)
3. **Technical Risks** — Identify potential blockers, unknowns, or edge cases
4. **Dependencies** — List any services, APIs, libraries, or teams involved
5. **Missing Information** — What questions need answering before work begins?
6. **Suggested Breakdown** — Sub-tasks or phases if applicable
7. **Definition of Done** — Concrete checklist for task completion

Format clearly with headers. Be precise and technical.`;
  }

  private jiraPrompt(opts: PromptOptions, ac: string): string {
    const acList =
      opts.criteria.length
        ? opts.criteria.map((c) => `☐ ${c}`).join('\n')
        : '☐ [Define acceptance criteria]';

    return `You are a technical project manager creating a Jira ticket.

## Task Description
${opts.task}

## Acceptance Criteria
${ac}

## Metadata
- Priority: ${opts.priority}
- Story Points: ${opts.storyPoints}
- Component: ${opts.component || 'Not specified'}

Generate a complete, production-ready Jira ticket using this exact format:

TICKET SUMMARY: [concise one-liner, imperative mood, max 10 words]

TYPE: [Story / Bug / Task / Epic / Spike]
PRIORITY: ${opts.priority}
STORY POINTS: ${opts.storyPoints}
COMPONENT: ${opts.component || 'TBD'}
LABELS: [2-4 relevant technical labels]

---
DESCRIPTION:

[2-3 sentence overview of what needs to be done and why]

---
USER STORY:

As a [role], I want to [action] so that [benefit].

---
ACCEPTANCE CRITERIA:

${acList}

---
TECHNICAL NOTES:

[Technical approach, architecture decisions, patterns, constraints]

---
OUT OF SCOPE:

[What is explicitly NOT included in this ticket]

---
DEPENDENCIES:

[Blocking tickets, external services, teams, or infrastructure]

---
DEFINITION OF DONE:

☐ Code reviewed and approved (min 2 reviewers)
☐ Unit tests written (>80% coverage on new code)
☐ Integration tests passing in CI
☐ Documentation updated (README / API docs / ADR if needed)
☐ Deployed to staging and smoke-tested
☐ Product owner sign-off received`;
  }

  private codeGenPrompt(task: string, ac: string, language: string): string {
    return `You are an expert ${language} developer. Implement a complete, production-ready solution.

## Task Description
${task}

## Acceptance Criteria
${ac}

Requirements:
- Language: ${language}
- Write clean, readable, maintainable code
- Include proper error handling and edge case coverage
- Add inline comments for non-obvious logic
- Follow ${language}-specific idioms and best practices

Generate complete, working code. Include:
1. All necessary imports / dependencies
2. Full implementation addressing every acceptance criterion
3. Helper functions or utilities where needed
4. Unit tests or usage examples that demonstrate correctness
5. A file header comment explaining the solution and key design decisions

Output ONLY the code — no surrounding prose or markdown fences.`;
  }

  private analyzeJiraPrompt(jiraText: string): string {
    return `You are an experienced technical project manager and software architect performing a Jira ticket review.

## Jira Ticket Content
${jiraText}

Provide a thorough, constructive analysis covering:

1. **Ticket Quality Score** — Rate 1–10 with a one-sentence justification
2. **Clarity Assessment** — Is the ticket clear and unambiguous? Highlight any vague wording
3. **Acceptance Criteria Review** — Are they complete, specific, measurable, and testable?
4. **Scope Analysis** — Is the scope appropriate? Any scope creep risks or missing scope?
5. **Missing Information** — What's unclear or absent that could cause miscommunication or rework?
6. **Technical Feasibility** — Any architectural concerns, hidden complexity, or blockers?
7. **Effort Assessment** — Is the story point estimate reasonable given the scope?
8. **Dependency Gaps** — Are all blockers and external dependencies identified?
9. **Risk Flags** — 🔴 Critical / 🟡 Medium issues that could derail delivery
10. **Improvement Suggestions** — Specific, actionable rewrites or additions for weak sections

Be constructive and reference exact parts of the ticket when giving feedback.`;
  }

  private analyzeCodePrompt(codeText: string, language: string): string {
    return `You are an expert ${language} code reviewer and software architect performing a thorough code review.

## Code Under Review
\`\`\`${language.toLowerCase()}
${codeText}
\`\`\`

Provide a comprehensive code review covering:

1. **Overall Quality Score** — Rate 1–10 with a brief executive summary
2. **Bugs & Logic Errors** — 🔴 Critical issues that cause incorrect behaviour or failures
3. **Security Vulnerabilities** — Injection risks, auth issues, data exposure, insecure defaults
4. **Performance Issues** — Inefficiencies, N+1 patterns, memory leaks, blocking operations
5. **Code Quality** — Readability, naming conventions, cyclomatic complexity, duplication (DRY)
6. **${language} Best Practices** — Language-specific idioms, anti-patterns, and missed conventions
7. **Error Handling** — Robustness, missing edge cases, swallowed exceptions
8. **Testing Gaps** — What should have tests but doesn't? What's hard to test due to structure?
9. **Refactoring Suggestions** — Concrete improvements with brief before/after code snippets
10. **Positive Observations** — What is done well (essential for a balanced, useful review)

Reference specific line numbers or function names where applicable. Be direct but constructive.`;
  }
}
