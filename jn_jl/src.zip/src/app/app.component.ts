import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ClaudeService } from './services/claude.service';
import { PromptBuilderService } from './services/prompt-builder.service';
import {
  AgentMode,
  CriterionItem,
  LANGUAGES,
  MODES,
  PRIORITIES,
  STORY_POINTS,
} from './models/types';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent {
  private readonly claude = inject(ClaudeService);
  private readonly promptBuilder = inject(PromptBuilderService);

  readonly createModes = MODES.filter((m) => m.group === 'create');
  readonly analyzeModes = MODES.filter((m) => m.group === 'analyze');
  readonly priorities = PRIORITIES;
  readonly languages = LANGUAGES;
  readonly storyPointOptions = STORY_POINTS;

  readonly selectedMode = signal<AgentMode>('evaluate');
  readonly currentMode = computed(() => MODES.find((m) => m.id === this.selectedMode())!);
  readonly isAnalyzeMode = computed(() => this.selectedMode().startsWith('analyze'));

  readonly task = signal('');
  readonly criteriaInput = signal('');
  readonly criteria = signal<CriterionItem[]>([]);
  readonly priority = signal('Medium');
  readonly storyPoints = signal('3');
  readonly language = signal('TypeScript');
  readonly component = signal('');

  readonly existingTicket = signal('');
  readonly existingCode = signal('');
  readonly codeLanguage = signal('TypeScript');

  readonly loading = signal(false);
  readonly output = signal('');
  readonly error = signal('');
  readonly copied = signal(false);

  private readonly runLabels: Record<AgentMode, string> = {
    evaluate:       'Run Evaluation →',
    jira:           'Generate Jira Ticket →',
    code:           'Generate Code →',
    'analyze-jira': 'Analyze Ticket →',
    'analyze-code': 'Analyze Code →',
  };

  private readonly loadingLabels: Record<AgentMode, string> = {
    evaluate:       '🔍 Evaluating task…',
    jira:           '📋 Generating ticket…',
    code:           '⚡ Writing code…',
    'analyze-jira': '🔬 Analyzing ticket…',
    'analyze-code': '🛡️ Reviewing code…',
  };

  private readonly outputLabels: Record<AgentMode, string> = {
    evaluate:       '// evaluation-report',
    jira:           '// jira-ticket',
    code:           '// generated-code',
    'analyze-jira': '// ticket-analysis',
    'analyze-code': '// code-review',
  };

  readonly runLabel = computed(() => this.runLabels[this.selectedMode()]);
  readonly loadingLabel = computed(() => this.loadingLabels[this.selectedMode()]);
  readonly outputLabel = computed(() => this.outputLabels[this.selectedMode()]);

  selectMode(mode: AgentMode): void {
    this.selectedMode.set(mode);
    this.output.set('');
    this.error.set('');
  }

  addCriterion(): void {
    const text = this.criteriaInput().trim();
    if (text && !this.criteria().some((c) => c.text === text)) {
      this.criteria.update((prev) => [...prev, { id: crypto.randomUUID(), text }]);
      this.criteriaInput.set('');
    }
  }

  removeCriterion(id: string): void {
    this.criteria.update((prev) => prev.filter((c) => c.id !== id));
  }

  onCriteriaKeydown(event: KeyboardEvent): void {
    if (event.key === 'Enter') {
      event.preventDefault();
      this.addCriterion();
    }
  }

  async run(): Promise<void> {
    this.error.set('');

    if (!this.isAnalyzeMode()) {
      if (!this.task().trim()) {
        this.error.set('Please describe the coding task.');
        return;
      }
    } else if (this.selectedMode() === 'analyze-jira') {
      if (!this.existingTicket().trim()) {
        this.error.set('Please paste the Jira ticket content to analyze.');
        return;
      }
    } else if (this.selectedMode() === 'analyze-code') {
      if (!this.existingCode().trim()) {
        this.error.set('Please paste the code to analyze.');
        return;
      }
    }

    this.loading.set(true);
    this.output.set('');

    try {
      const prompt = this.promptBuilder.build({
        mode: this.selectedMode(),
        task: this.task(),
        criteria: this.criteria().map((c) => c.text),
        priority: this.priority(),
        storyPoints: this.storyPoints(),
        language: this.language(),
        component: this.component(),
        existingTicket: this.existingTicket(),
        existingCode: this.existingCode(),
        codeLanguage: this.codeLanguage(),
      });

      const result = await this.claude.sendMessage(prompt);
      this.output.set(result);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Unknown error';
      this.error.set(`Agent error: ${msg}`);
    } finally {
      this.loading.set(false);
    }
  }

  async copyOutput(): Promise<void> {
    await navigator.clipboard.writeText(this.output());
    this.copied.set(true);
    setTimeout(() => this.copied.set(false), 2000);
  }
}
