export type AgentMode = 'evaluate' | 'jira' | 'code' | 'analyze-jira' | 'analyze-code';

export interface ModeConfig {
  id: AgentMode;
  label: string;
  icon: string;
  description: string;
  group: 'create' | 'analyze';
  badge?: string;
}

export interface CriterionItem {
  id: string;
  text: string;
}

export const MODES: ModeConfig[] = [
  {
    id: 'evaluate',
    label: 'Evaluate Task',
    icon: '🔍',
    description: 'Analyze complexity, risks & effort estimate',
    group: 'create',
  },
  {
    id: 'jira',
    label: 'Create Jira Ticket',
    icon: '📋',
    description: 'Generate a structured, Jira-ready ticket',
    group: 'create',
  },
  {
    id: 'code',
    label: 'Generate Code',
    icon: '⚡',
    description: 'Translate requirements into working code',
    group: 'create',
  },
  {
    id: 'analyze-jira',
    label: 'Analyze Jira Ticket',
    icon: '🔬',
    description: 'Review & improve an existing Jira ticket',
    group: 'analyze',
    badge: 'NEW',
  },
  {
    id: 'analyze-code',
    label: 'Analyze Code',
    icon: '🛡️',
    description: 'Review existing code for bugs, security & perf',
    group: 'analyze',
    badge: 'NEW',
  },
];

export const PRIORITIES = ['Critical', 'High', 'Medium', 'Low'] as const;
export const LANGUAGES = [
  'TypeScript', 'JavaScript', 'Python', 'Java',
  'Go', 'Rust', 'C#', 'Ruby', 'Swift', 'Kotlin',
] as const;
export const STORY_POINTS = ['1', '2', '3', '5', '8', '13', '21'] as const;
