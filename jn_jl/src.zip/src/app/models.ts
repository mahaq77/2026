export type Mode =
  | 'evaluate'
  | 'jira'
  | 'code'
  | 'analyze-jira'
  | 'analyze-code';

export interface ModeConfig {
  id: Mode;
  label: string;
  icon: string;
  desc: string;
}

export const MODES: ModeConfig[] = [
  {
    id: 'evaluate',
    label: 'Evaluate Task',
    icon: '🔍',
    desc: 'Analyse complexity, risks & effort',
  },
  {
    id: 'jira',
    label: 'Generate Jira',
    icon: '📋',
    desc: 'Create a structured Jira ticket',
  },
  {
    id: 'code',
    label: 'Generate Code',
    icon: '⚡',
    desc: 'Translate requirements into code',
  },
  {
    id: 'analyze-jira',
    label: 'Analyze Jira',
    icon: '🎯',
    desc: 'Review an existing Jira ticket',
  },
  {
    id: 'analyze-code',
    label: 'Analyze Code',
    icon: '🔬',
    desc: 'Code review & improvement tips',
  },
];

export const PRIORITIES: string[] = ['Critical', 'High', 'Medium', 'Low'];

export const STORY_POINTS: string[] = ['1', '2', '3', '5', '8', '13', '21'];

export const LANGUAGES: string[] = [
  'TypeScript',
  'JavaScript',
  'Python',
  'Java',
  'Go',
  'Rust',
  'C#',
  'Ruby',
  'Swift',
  'Kotlin',
];

export const OUTPUT_TITLES: Record<Mode, string> = {
  evaluate: '// evaluation-report',
  jira: '// jira-ticket',
  code: '// generated-code',
  'analyze-jira': '// jira-analysis',
  'analyze-code': '// code-review',
};
