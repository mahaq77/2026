import { Injectable } from '@angular/core';
import { AgentMode } from '../models/types';

export interface PromptParams {
  mode: AgentMode;
  task?: string;
  criteria?: string[];
  priority?: string;
  language?: string;
  storyPoints?: string;
  component?: string;
  existingTicket?: string;
  existingCode?: string;
  codeLanguage?: string;
}

@Injectable({ providedIn: 'root' })
export class PromptBuilderService {
  build(p: PromptParams): string {
    switch (p.mode) {
      case 'evaluate':      return this.evaluate(p);
      case 'jira':          return this.jira(p);
      case 'code':          return this.code(p);
      case 'analyze-jira':  return this.analyzeJira(p);
      case 'analyze-code':  return this.analyzeCode(p);
    }
  }

  private ac(criteria: string[] = []): string {
    return criteria.length
      ? criteria.map((c, i) => `${i + 1}. ${c}`).join('\n')
      : 'None provided';
  }

  private evaluate(p: PromptParams): string {
    return `You are a senior software engineer performing a rigorous task evaluation.

## Task Description
${p.task}

## Acceptance Criteria
${this.ac(p.criteria)}

Provide a structured evaluation report with the following sections:

1. **Task Complexity** — Simple / Moderate / Complex / Very Complex, with clear reasoning
2. **Effort Estimate** — Story points and time range (optimistic / realistic / pessimistic)
3. **Technical Risks** — Blockers, unknowns, integration challenges, edge cases
4. **Dependencies** — External services, APIs, libraries, or other teams involved
5. **Missing Information** — Questions that must be answered before work can begin
6. **Suggested Breakdown** — Recommended sub-tasks or phases (if applicable)
7. **Definition of Done** — Concrete, verifiable checklist

Be precise and technically rigorous.`;
  }

  private jira(p: PromptParams): string {
    const acList = p.criteria?.length
      ? p.criteria.map(c => `☐ ${c}`).join('\n')
      : '☐ Define acceptance criteria';

    return `You are a technical project manager creating a production-ready Jira ticket.

## Task Description
${p.task}

## Acceptance Criteria
${this.ac(p.criteria)}

## Metadata
- Priority: ${p.priority}
- Story Points: ${p.storyPoints}
- Component: ${p.component || 'Not specified'}

Generate a complete Jira ticket using this exact format:

TICKET SUMMARY: [concise one-liner in imperative mood]

TYPE: [Story / Bug / Task / Epic / Spike]
PRIORITY: ${p.priority}
STORY POINTS: ${p.storyPoints}
COMPONENT: ${p.component || 'TBD'}
LABELS: [space-separated relevant labels]

---
DESCRIPTION:

[2–3 sentences explaining what needs to be done and the business value]

---
USER STORY:

As a [role], I want to [action] so that [benefit].

---
ACCEPTANCE CRITERIA:

${acList}

---
TECHNICAL NOTES:

[Architecture decisions, implementation approach, technical constraints]

---
OUT OF SCOPE:

[Explicitly list what is NOT included in this ticket]

---
DEPENDENCIES:

[Blocking tickets, downstream services, external teams]

---
DEFINITION OF DONE:

☐ Code reviewed and approved by 2+ engineers
☐ Unit tests written (≥80% coverage)
☐ Integration/E2E tests passing
☐ Documentation updated (README, API docs, runbook)
☐ Deployed to staging and smoke-tested
☐ Product owner sign-off received`;
  }

  private code(p: PromptParams): string {
    return `You are an expert ${p.language} developer. Write a complete, production-ready implementation.

## Task Description
${p.task}

## Acceptance Criteria
${this.ac(p.criteria)}

## Requirements
- Language: ${p.language}
- Write clean, readable, maintainable code
- Full error handling and edge cases
- Inline comments on non-obvious logic
- Follow ${p.language} idioms and best practices (SOLID, DRY, etc.)

Deliver complete, runnable code including:
1. All imports and dependencies
2. Main implementation with full logic
3. Helper utilities or types if needed
4. Unit tests or usage examples
5. A top-level doc comment explaining the solution and trade-offs

Output ONLY the code — no markdown wrappers, no external explanation.`;
  }

  private analyzeJira(p: PromptParams): string {
    return `You are a senior technical project manager and Agile practitioner conducting a ticket quality audit.

## Existing Jira Ticket
${p.existingTicket}

Produce a detailed, structured analysis:

1. **Quality Score** — Rate the ticket 1–10 with clear justification
2. **Clarity Assessment** — Is the description unambiguous? Could two engineers interpret it differently?
3. **Acceptance Criteria Review** — Are they testable, specific, and complete (SMART criteria)?
4. **Missing Information** — What critical details are absent that would block a developer?
5. **Scope Analysis** — Is the ticket too broad (epic-level), too narrow, or well-scoped?
6. **Effort Assessment** — Does the estimate seem accurate? Any hidden complexity?
7. **Risk Flags** — Red flags, assumptions baked in, or dependencies not called out
8. **Rewritten Version** — Provide an improved version of the Description, AC, and Technical Notes
9. **Action Items** — Prioritized list of changes needed before this ticket enters a sprint

Be direct, specific, and technically honest. Flag problems clearly.`;
  }

  private analyzeCode(p: PromptParams): string {
    return `You are a principal software engineer conducting a thorough code review.

## Language
${p.codeLanguage}

## Code Under Review
\`\`\`${p.codeLanguage?.toLowerCase()}
${p.existingCode}
\`\`\`

Provide a comprehensive structured review:

1. **Overall Assessment** — Quality rating (1–10), readability, and maintainability verdict
2. **Bugs & Logical Errors** — List all bugs found with line references and corrected code snippets
3. **Security Vulnerabilities** — Injection flaws, auth issues, data exposure, insecure dependencies
4. **Performance Issues** — Inefficient algorithms (with Big-O), memory leaks, redundant operations
5. **Code Quality** — Naming, duplication (DRY), single responsibility, magic numbers/strings
6. **Error Handling** — Missing try/catch, silent failures, improper error propagation
7. **Test Coverage Gaps** — Which paths, edge cases, or functions lack tests
8. **Refactoring Suggestions** — Before/after code examples for the top improvements
9. **Dependency Audit** — Unused imports, outdated packages, known CVEs
10. **Top 3 Critical Issues** — The most urgent fixes, ranked by impact

Be specific with line numbers and always include corrected code examples.`;
  }
}
