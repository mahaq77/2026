import { Injectable } from '@angular/core';

export interface AgentResponse {
  text: string;
}

@Injectable({ providedIn: 'root' })
export class AgentService {
  private readonly API_URL = 'https://api.anthropic.com/v1/messages';
  private readonly MODEL = 'claude-sonnet-4-20250514';

  async call(apiKey: string, prompt: string): Promise<string> {
    const response = await fetch(this.API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-calls': 'true',
      },
      body: JSON.stringify({
        model: this.MODEL,
        max_tokens: 2048,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(
        (err as { error?: { message?: string } }).error?.message ??
          `HTTP ${response.status}`
      );
    }

    const data = (await response.json()) as {
      content: Array<{ type: string; text?: string }>;
    };

    return (
      data.content
        .filter((b) => b.type === 'text')
        .map((b) => b.text ?? '')
        .join('') || ''
    );
  }
}
