# Coding Task Agent — Angular 20

An AI-powered agent built with **Angular 20** and the **Anthropic Claude API**.

## Modes

### Create
| Mode | Description |
|------|-------------|
| 🔍 Evaluate Task | Analyse complexity, technical risks, effort estimate, and definition of done |
| 📋 Create Jira Ticket | Generate a fully structured Jira-ready ticket with user story, AC, technical notes, and DoD |
| ⚡ Generate Code | Translate requirements and acceptance criteria into working, production-ready code |

### Analyze (New)
| Mode | Description |
|------|-------------|
| 🔬 Analyze Jira Ticket | Paste an existing ticket and get a quality audit, missing info, risk flags, and an improved rewrite |
| 🛡️ Analyze Code | Paste existing code and get a detailed review covering bugs, security, performance, and refactoring suggestions |

## Tech Stack

- **Angular 20** — Standalone components, Signals (`signal`, `computed`), new `@if` / `@for` / `@switch` template syntax
- **TypeScript 5.8** — Strict mode
- **SCSS** — Component-scoped styles, design tokens
- **Anthropic Claude API** — `claude-sonnet-4-20250514`

## Key Angular 20 Features Used

- `signal()` and `computed()` for reactive state (no RxJS needed for local state)
- New template control flow: `@if`, `@for`, `@switch`
- `inject()` for dependency injection in constructor
- Standalone components (no NgModule)
- `provideZoneChangeDetection` with event coalescing

## Getting Started

```bash
npm install
npm start
```

Open http://localhost:4200

## Project Structure

```
src/
├── app/
│   ├── models/
│   │   └── types.ts           # AgentMode, ModeConfig, constants
│   ├── services/
│   │   ├── claude.service.ts        # Anthropic API calls
│   │   └── prompt-builder.service.ts # Prompt construction for each mode
│   ├── app.component.ts       # Main component — all state & logic
│   ├── app.component.html     # Template with Angular 20 control flow
│   ├── app.component.scss     # Scoped dark-theme styles
│   └── app.config.ts          # App providers
├── main.ts                    # Bootstrap
├── index.html
└── styles.scss                # Global styles
```
