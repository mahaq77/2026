# Common Style Library - Angular Material 20 Edition

A comprehensive, optimized SCSS library designed for Angular Material 20+ applications with full theme support, accessibility features, and backward compatibility.

## 🌟 Features

- **Angular Material 20 Compatible**: Full support for Material Design 3 components
- **Dynamic Theming**: Light/Dark theme support with CSS custom properties
- **Accessibility First**: WCAG 2.1 compliant with focus management and high contrast support
- **Performance Optimized**: Tree-shakeable imports and critical CSS identification
- **Backward Compatible**: Legacy class support for smooth migration
- **Responsive Design**: Mobile-first approach with comprehensive breakpoint system
- **Utility Classes**: Extensive utility system for rapid development

## 📦 Installation

```bash
npm install common-style-lib
```

### Peer Dependencies

```bash
npm install @angular/material @angular/cdk @angular/core sass
```

## 🚀 Quick Start

### 1. Import the Optimized Styles

```scss
// In your main styles.scss
@import '~common-style-lib/src/index-optimized.scss';
```

### 2. Configure Angular Material

```typescript
// app.module.ts
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';

@NgModule({
  imports: [
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatCardModule,
    // ... other modules
  ],
})
export class AppModule { }
```

### 3. Use Components

```html
<!-- Modern Material Design 3 components -->
<mat-card>
  <mat-card-header>
    <mat-card-title>Welcome</mat-card-title>
  </mat-card-header>
  <mat-card-content>
    <mat-form-field appearance="outline">
      <mat-label>Email</mat-label>
      <input matInput type="email">
    </mat-form-field>
  </mat-card-content>
  <mat-card-actions>
    <button mat-raised-button color="primary">Submit</button>
    <button mat-outlined-button>Cancel</button>
  </mat-card-actions>
</mat-card>
```

## 🎨 Theming

### Automatic Theme Detection

The library automatically detects system preferences:

```scss
// Automatically applies dark theme if user prefers dark mode
@media (prefers-color-scheme: dark) {
  :root:not([data-theme]) {
    @include dark-theme;
  }
}
```

### Manual Theme Switching

```typescript
// theme.service.ts
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class ThemeService {
  toggleTheme(): void {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', newTheme);
  }
}
```

```html
<!-- Theme toggle button -->
<button mat-icon-button (click)="themeService.toggleTheme()">
  <mat-icon>dark_mode</mat-icon>
</button>
```

### Custom Theme Colors

```scss
// Override theme variables
:root {
  --brand-cyan: #your-primary-color;
  --brand-cyan-hover: #your-primary-hover;
  --text-primary: #your-text-color;
  --bg-primary: #your-background-color;
}
```

## 🛠️ Utility Classes

### Layout & Flexbox

```html
<!-- Flexbox utilities -->
<div class="d-flex justify-content-center align-items-center">
  <div class="flex-grow-1">Content</div>
</div>

<!-- Grid utilities -->
<div class="d-grid" style="grid-template-columns: 1fr 1fr;">
  <div>Column 1</div>
  <div>Column 2</div>
</div>
```

### Spacing

```html
<!-- Margin and padding -->
<div class="m-4 p-3">Margin 1rem, Padding 0.75rem</div>
<div class="mx-auto">Centered horizontally</div>
<div class="py-2">Vertical padding 0.5rem</div>
```

### Typography

```html
<!-- Font sizes and weights -->
<h1 class="text-2xl fw-bold">Large Bold Heading</h1>
<p class="text-base fw-normal text-secondary">Regular paragraph</p>
<small class="text-sm text-disabled">Small disabled text</small>
```

### Colors

```html
<!-- Text colors -->
<p class="text-primary">Primary text</p>
<p class="text-success">Success message</p>
<p class="text-error">Error message</p>

<!-- Background colors -->
<div class="bg-primary text-on-primary">Primary background</div>
<div class="bg-success text-white">Success background</div>
```

### Responsive Utilities

```html
<!-- Responsive display -->
<div class="d-none d-md-block">Hidden on mobile, visible on tablet+</div>
<div class="d-flex d-lg-grid">Flex on mobile, grid on desktop</div>

<!-- Responsive text alignment -->
<p class="text-center text-md-left">Centered on mobile, left on tablet+</p>
```

## 📱 Responsive Design

### Breakpoint System

```scss
$breakpoints: (
  xs: 0,
  sm: 576px,
  md: 768px,
  lg: 992px,
  xl: 1200px,
  xxl: 1400px
);
```

### Using Mixins

```scss
.my-component {
  padding: 1rem;
  
  @include respond-to(md) {
    padding: 2rem;
  }
  
  @include respond-to(lg) {
    padding: 3rem;
  }
}
```

### Container System

```html
<!-- Responsive containers -->
<div class="container">
  <!-- Max-width containers with responsive breakpoints -->
</div>

<div class="container-fluid">
  <!-- Full-width container -->
</div>
```

## ♿ Accessibility Features

### Focus Management

```scss
// Automatic focus indicators
.mat-mdc-button:focus-visible {
  outline: 2px solid var(--brand-cyan);
  outline-offset: 2px;
}
```

### High Contrast Support

```scss
@media (prefers-contrast: high) {
  .mat-mdc-button {
    border-width: 2px;
  }
}
```

### Reduced Motion Support

```scss
@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```

### Screen Reader Support

```html
<!-- Screen reader only content -->
<span class="sr-only">Additional context for screen readers</span>

<!-- Skip links -->
<a href="#main-content" class="skip-link">Skip to main content</a>
```

## 🔧 Advanced Usage

### Custom Component Styling

```scss
// Using provided mixins
.my-custom-button {
  @include button-variant(
    var(--brand-cyan),
    var(--text-on-primary),
    var(--brand-cyan-hover)
  );
  @include border-radius(lg);
  @include elevation(2);
  @include transition(fast);
}
```

### Creating Custom Themes

```scss
// custom-theme.scss
@import '~common-style-lib/src/themes/variables';
@import '~common-style-lib/src/themes/mixins';

$custom-primary: (
  50: #e3f2fd,
  500: #2196f3,
  // ... other shades
);

:root[data-theme="custom"] {
  --mat-primary-500: #{map-get($custom-primary, 500)};
  // ... other custom properties
}
```

### Performance Optimization

```scss
// Critical CSS (inline in <head>)
/* critical:start */
body { font-family: Whitney, sans-serif; }
.mat-mdc-button { font-family: Whitney, sans-serif; }
/* critical:end */

// Non-critical CSS (load asynchronously)
/* non-critical:start */
.complex-animation { /* ... */ }
/* non-critical:end */
```

## 📚 Component Documentation

### Buttons

```html
<!-- Primary buttons -->
<button mat-raised-button color="primary">Raised Primary</button>
<button mat-unelevated-button color="primary">Flat Primary</button>

<!-- Secondary buttons -->
<button mat-outlined-button color="primary">Outlined</button>
<button mat-button color="primary">Text Button</button>

<!-- Icon buttons -->
<button mat-icon-button color="primary">
  <mat-icon>favorite</mat-icon>
</button>

<!-- FAB buttons -->
<button mat-fab color="primary">
  <mat-icon>add</mat-icon>
</button>
```

### Form Fields

```html
<!-- Outline appearance (recommended) -->
<mat-form-field appearance="outline">
  <mat-label>Email</mat-label>
  <input matInput type="email" required>
  <mat-error>Email is required</mat-error>
  <mat-hint>We'll never share your email</mat-hint>
</mat-form-field>

<!-- Fill appearance -->
<mat-form-field appearance="fill">
  <mat-label>Password</mat-label>
  <input matInput type="password" required>
  <mat-icon matSuffix>visibility</mat-icon>
</mat-form-field>
```

### Cards

```html
<!-- Basic card -->
<mat-card>
  <mat-card-header>
    <div mat-card-avatar class="example-header-image"></div>
    <mat-card-title>Card Title</mat-card-title>
    <mat-card-subtitle>Card Subtitle</mat-card-subtitle>
  </mat-card-header>
  <img mat-card-image src="path/to/image.jpg" alt="Photo">
  <mat-card-content>
    <p>Card content goes here.</p>
  </mat-card-content>
  <mat-card-actions>
    <button mat-button>LIKE</button>
    <button mat-button>SHARE</button>
  </mat-card-actions>
</mat-card>
```

## 🔄 Migration from Legacy

See [MIGRATION-GUIDE.md](./MIGRATION-GUIDE.md) for detailed migration instructions.

### Quick Migration Checklist

- [ ] Update imports to use `index-optimized.scss`
- [ ] Replace hardcoded colors with CSS custom properties
- [ ] Update Material component classes (e.g., `mat-button` → `mat-mdc-button`)
- [ ] Test theme switching functionality
- [ ] Verify accessibility features
- [ ] Update build scripts if needed

## 🏗️ Build Scripts

```bash
# Build optimized CSS (outputs to dist/common-style-lib/common-style-lib.css)
npm run build

# Build optimized CSS (same as above)
npm run build:optimized

# Build legacy CSS (outputs to dist/common-style-lib/common-style-lib-legacy.css)
npm run build:legacy

# Build original version (outputs to dist/common-style-lib/common-style-lib-original.css)
npm run build:original

# Watch for changes
npm run watch

# Lint SCSS files
npm run lint:scss
```

## 🧪 Testing

### Visual Regression Testing

```bash
# Test both themes
npm run test:visual -- --theme=light
npm run test:visual -- --theme=dark
```

### Accessibility Testing

```bash
# Run accessibility audits
npm run test:a11y
```

## 📈 Performance

### Bundle Size

- **Optimized build** (`dist/common-style-lib/common-style-lib.css`): ~45KB gzipped
- **Legacy build** (`dist/common-style-lib/common-style-lib-legacy.css`): ~78KB gzipped
- **Tree-shakeable**: Import only what you need

### Loading Strategy

```html
<!-- Critical CSS inline -->
<style>/* critical CSS here */</style>

<!-- Non-critical CSS async -->
<link rel="preload" href="styles.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

### Development Setup

```bash
git clone <repository-url>
cd common-style-lib
npm install
npm run watch
```

## 📄 License

MIT License - see [LICENSE](./LICENSE) file for details.

## 🆘 Support

- 📖 [Documentation](./docs/)
- 🐛 [Issue Tracker](./issues)
- 💬 [Discussions](./discussions)
- 📧 [Email Support](mailto:support@yourorg.com)

---

**Made with ❤️ for Angular developers**