#!/usr/bin/env node
/**
 * Compiles scss/styles.scss (and everything it @use's - theme partials plus
 * every Angular Material component partial it pulls in) into one static
 * dist/global-styles.css file, using the sass JS API directly (no sass CLI
 * needed once dependencies are installed).
 *
 * Usage:
 *   node build.js            one-off compressed build
 *   node build.js --dev       one-off, readable/uncompressed build
 *   node build.js --watch     rebuild automatically when any .scss changes
 */

const fs = require('fs');
const path = require('path');
const sass = require('sass');

const ROOT = __dirname;
const ENTRY = path.join(ROOT, 'scss', 'styles.scss');
const OUT_DIR = path.join(ROOT, 'dist');
const OUT_FILE = path.join(OUT_DIR, 'global-styles.css');

const isDev = process.argv.includes('--dev');
const isWatch = process.argv.includes('--watch');

function build() {
  const start = Date.now();
  try {
    const result = sass.compile(ENTRY, {
      style: isDev ? 'expanded' : 'compressed',
      sourceMap: false,
      loadPaths: [path.join(ROOT, 'node_modules')],
    });

    fs.mkdirSync(OUT_DIR, { recursive: true });
    fs.writeFileSync(OUT_FILE, result.css);

    const kb = (Buffer.byteLength(result.css) / 1024).toFixed(1);
    const ms = Date.now() - start;
    console.log(`[build] wrote ${path.relative(ROOT, OUT_FILE)} (${kb} KB) in ${ms}ms`);
  } catch (err) {
    console.error('[build] failed:\n', err.message || err);
    if (!isWatch) process.exit(1);
  }
}

build();

if (isWatch) {
  const scssDir = path.join(ROOT, 'scss');
  console.log(`[watch] watching ${path.relative(ROOT, scssDir)} for changes...`);
  let pending = false;
  fs.watch(scssDir, { recursive: true }, () => {
    if (pending) return; // debounce bursts of fs events
    pending = true;
    setTimeout(() => {
      pending = false;
      build();
    }, 100);
  });
}
