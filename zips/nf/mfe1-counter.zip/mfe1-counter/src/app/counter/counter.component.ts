/**
 * CounterComponent — MFE1
 * Exposed via NF as './CounterComponent'
 *
 * Inside Shell: inject(SharedStateService) gets the Shell's root singleton
 *   → direct in-process signal update, zero latency.
 * Standalone / cross-tab: BroadcastChannel syncs state.
 */
import { Component, inject, signal } from '@angular/core';
import { SharedStateService } from '../services/shared-state.service';

@Component({
  selector: 'mfe1-counter',
  standalone: true,
  template: `
    <div class="card">
      <h2>Counter <span class="tag">MFE1</span></h2>
      <p class="desc">Mutates the shared <code>count</code> signal.
        Shell header and MFE2 react instantly.</p>

      <div class="display" [class.bump]="bumped()">
        <span class="val">{{ s.count() }}</span>
        <span class="sub">current count</span>
      </div>

      <div class="computed-row">
        <div class="ci"><span class="cl">count × 2</span><span class="cv">{{ s.doubleCount() }}</span></div>
        <div class="ci"><span class="cl">last action</span><span class="cv act">{{ s.lastAction() }}</span></div>
        <div class="ci"><span class="cl">greeting</span><span class="cv greet">{{ s.greeting() }}</span></div>
      </div>

      <div class="actions">
        <button class="btn btn-danger"    (click)="dec()">−  Decrement</button>
        <button class="btn btn-secondary" (click)="reset()">↺  Reset</button>
        <button class="btn btn-primary"   (click)="inc()">+  Increment</button>
      </div>
    </div>
  `,
  styles: [`
    .card{background:var(--color-surface);border:1px solid var(--color-border);
      border-radius:var(--radius-lg);padding:2rem;max-width:520px;box-shadow:var(--shadow-md)}
    h2{font-size:1.5rem;font-weight:700;margin-bottom:.4rem}
    .desc{font-size:.85rem;color:var(--color-muted);margin-bottom:1.5rem;line-height:1.5}
    code{background:#f1f5f9;padding:.1em .3em;border-radius:4px;font-size:.8em}
    .display{display:flex;flex-direction:column;align-items:center;gap:.25rem;
      margin-bottom:1.5rem;transition:transform .15s}
    .display.bump{transform:scale(1.08)}
    .val{font-size:5rem;font-weight:800;color:var(--color-primary);
      line-height:1;font-variant-numeric:tabular-nums}
    .sub{font-size:.75rem;text-transform:uppercase;letter-spacing:.08em;color:var(--color-muted)}
    .computed-row{display:grid;grid-template-columns:repeat(3,1fr);gap:.75rem;
      margin-bottom:1.75rem;padding:1rem;background:#f8fafc;
      border:1px solid var(--color-border);border-radius:var(--radius)}
    .ci{display:flex;flex-direction:column;gap:.2rem;text-align:center}
    .cl{font-size:.65rem;text-transform:uppercase;letter-spacing:.07em;color:var(--color-muted)}
    .cv{font-size:1rem;font-weight:600}
    .cv.act{color:var(--color-warning);font-style:italic}
    .cv.greet{color:var(--color-success);font-size:.85rem}
    .actions{display:flex;gap:.75rem;justify-content:center}
    .actions .btn{min-width:110px;justify-content:center}
  `]
})
export class CounterComponent {
  protected readonly s      = inject(SharedStateService);
  protected readonly bumped = signal(false);

  protected inc():   void { this.s.increment(); this.bump(); }
  protected dec():   void { this.s.decrement(); this.bump(); }
  protected reset(): void { this.s.reset();     this.bump(); }

  private bump(): void {
    this.bumped.set(true);
    setTimeout(() => this.bumped.set(false), 200);
  }
}
