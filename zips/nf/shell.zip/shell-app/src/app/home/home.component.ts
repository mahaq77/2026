import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { SharedStateService } from '../services/shared-state.service';
@Component({
  selector: 'app-home', standalone: true, imports: [RouterLink],
  template: `
    <div class="home">
      <h1>Angular 22 MFE Demo</h1>
      <p style="color:var(--color-muted);margin-bottom:2rem">Native Federation · Signals · BroadcastChannel</p>
      <div class="state-grid">
        <div class="si"><span class="sl">count</span><span class="sv">{{ s.count() }}</span></div>
        <div class="si"><span class="sl">doubleCount</span><span class="sv">{{ s.doubleCount() }}</span></div>
        <div class="si"><span class="sl">user</span><span class="sv">{{ s.user().avatar }} {{ s.user().name }}</span></div>
        <div class="si"><span class="sl">lastAction</span><span class="sv">{{ s.lastAction() }}</span></div>
        <div class="si"><span class="sl">greeting</span><span class="sv">{{ s.greeting() }}</span></div>
        <div class="si"><span class="sl">isLoggedIn</span><span class="sv">{{ s.isLoggedIn() }}</span></div>
      </div>
      <div style="display:flex;gap:1rem;margin-top:2rem">
        <a routerLink="/counter" class="btn btn-primary">Counter MFE →</a>
        <a routerLink="/profile"  class="btn btn-secondary">Profile MFE →</a>
      </div>
    </div>
  `,
  styles: [`.home{max-width:700px}h1{font-size:1.75rem;font-weight:700;margin-bottom:.5rem}
    .state-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:.75rem;
      background:#f1f5f9;border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:1.25rem}
    .si{display:flex;flex-direction:column;gap:.2rem}
    .sl{font-size:.7rem;text-transform:uppercase;letter-spacing:.06em;color:var(--color-muted)}
    .sv{font-size:1.1rem;font-weight:600;color:var(--color-primary)}`]
})
export class HomeComponent { protected readonly s = inject(SharedStateService); }
