import { Component, inject } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { SharedStateService } from './services/shared-state.service';
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <header class="shell-header">
      <div class="brand">
        <span>⚡</span>
        <span class="brand-name">MFE Shell</span>
        <span class="tag">Angular 22</span>
      </div>
      <nav class="shell-nav">
        <a routerLink="/" routerLinkActive="active" [routerLinkActiveOptions]="{exact:true}">Home</a>
        <a routerLink="/counter" routerLinkActive="active">Counter MFE</a>
        <a routerLink="/profile"  routerLinkActive="active">Profile MFE</a>
      </nav>
      <div class="state-bar">
        <span class="chip">🔢 <b>{{ s.count() }}</b></span>
        <span class="chip">×2 <b>{{ s.doubleCount() }}</b></span>
        <span class="chip user" [class.on]="s.isLoggedIn()">{{ s.user().avatar }} {{ s.user().name }}</span>
        <span class="chip action">↻ {{ s.lastAction() }}</span>
      </div>
    </header>
    <main class="shell-content"><router-outlet /></main>
    <footer class="shell-footer">Angular 22 · Native Federation · Signals · BroadcastChannel</footer>
  `,
  styleUrl: './app.component.scss',
})
export class AppComponent { protected readonly s = inject(SharedStateService); }
