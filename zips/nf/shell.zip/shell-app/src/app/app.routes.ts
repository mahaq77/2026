import { Routes } from '@angular/router';
import { loadRemoteModule } from '@angular-architects/native-federation';
export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./home/home.component').then(m => m.HomeComponent),
    title: 'Shell — Home',
  },
  {
    path: 'counter',
    loadComponent: () =>
      loadRemoteModule('mfe1', './CounterComponent').then(m => m.CounterComponent),
    title: 'Counter MFE',
  },
  {
    path: 'profile',
    loadComponent: () =>
      loadRemoteModule('mfe2', './UserProfileComponent').then(m => m.UserProfileComponent),
    title: 'User Profile MFE',
  },
  { path: '**', redirectTo: '' },
];
