import { Injectable, OnDestroy, signal, computed } from '@angular/core';

export interface UserProfile { name: string; email: string; avatar: string; }

type MsgType = 'COUNT_SET' | 'USER_SET' | 'ACTION_SET';
interface Msg { type: MsgType; payload: number | UserProfile | string; }

const DEFAULT_USER: UserProfile = { name: 'Guest', email: '', avatar: '👤' };

@Injectable({ providedIn: 'root' })
export class SharedStateService implements OnDestroy {

  // ── Writable signals ──────────────────────────────────────────────
  readonly count      = signal(0);
  readonly user       = signal<UserProfile>({ ...DEFAULT_USER });
  readonly lastAction = signal<string>('—');

  // ── Computed signals ──────────────────────────────────────────────
  readonly doubleCount = computed(() => this.count() * 2);
  readonly greeting    = computed(() => `Hello, ${this.user().name}!`);
  readonly isLoggedIn  = computed(() => this.user().name !== 'Guest');

  private readonly bc      = new BroadcastChannel('ng22-mfe-state');
  private readonly handler = (e: MessageEvent<Msg>) => this.apply(e.data);

  constructor() { this.bc.addEventListener('message', this.handler); }

  // ── Actions ────────────────────────────────────────────────────────
  increment(): void { this.update('COUNT_SET', this.count() + 1); this.update('ACTION_SET', 'increment'); }
  decrement(): void { this.update('COUNT_SET', this.count() - 1); this.update('ACTION_SET', 'decrement'); }
  reset():     void { this.update('COUNT_SET', 0);                this.update('ACTION_SET', 'reset'); }

  setUser(u: Partial<UserProfile>): void {
    this.update('USER_SET', { ...this.user(), ...u });
    this.update('ACTION_SET', 'user-updated');
  }

  private update(type: MsgType, payload: Msg['payload']): void {
    this.apply({ type, payload });
    this.bc.postMessage({ type, payload });
  }

  private apply({ type, payload }: Msg): void {
    if (type === 'COUNT_SET')  this.count.set(payload as number);
    if (type === 'USER_SET')   this.user.set(payload as UserProfile);
    if (type === 'ACTION_SET') this.lastAction.set(payload as string);
  }

  ngOnDestroy(): void {
    this.bc.removeEventListener('message', this.handler);
    this.bc.close();
  }
}