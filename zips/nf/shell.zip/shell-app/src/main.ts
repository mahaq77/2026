import { initFederation } from '@angular-architects/native-federation';
// Swap these URLs for your deployed MFE domains in production
initFederation({
  mfe1: 'http://localhost:4201/remoteEntry.json',
  mfe2: 'http://localhost:4202/remoteEntry.json',
})
  .catch(console.error)
  .then(() => import('./bootstrap'))
  .catch(console.error);
