/**
 * UserProfileComponent — MFE2
 * Exposed via NF as './UserProfileComponent'
 *
 * READ  → displays count signal from MFE1 (live via BroadcastChannel or shared injector)
 * WRITE → mutates user signal (Shell header greeting updates instantly)
 */
import { Component, inject, signal, computed } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SharedStateService, UserProfile } from '../services/shared-state.service';

const AVATARS = ['👤','😊','🚀','🦁','🐉','🌟','🎯','💡'] as const;

@Component({
  selector: 'mfe2-user-profile',
  standalone: true,
  imports: [FormsModule],
  template: `
    <div class="card">
      <h2>User Profile <span class="tag">MFE2</span></h2>
      <p class="desc">Reads <code>count</code> from MFE1. Writes <code>user</code> signal — Shell header updates instantly.</p>

      <!-- Live counter from MFE1 -->
      <div class="live-box">
        <span class="live-label">Live count from MFE1</span>
        <span class="live-val">{{ s.count() }}</span>
        <span class="live-sub">× 2 = {{ s.doubleCount() }}</span>
      </div>

      <!-- Profile view -->
      @if (!editing()) {
        <div class="profile-row">
          <div class="avatar-ring">{{ s.user().avatar }}</div>
          <div class="info">
            <h3>{{ s.user().name }}</h3>
            <p class="email">{{ s.user().email || 'No email set' }}</p>
            <span class="badge" [class.on]="s.isLoggedIn()">{{ s.isLoggedIn() ? '● Active' : '○ Guest' }}</span>
          </div>
          <div class="pactions">
            <button class="btn btn-primary"   (click)="startEdit()">Edit Profile</button>
            @if (s.isLoggedIn()) {
              <button class="btn btn-secondary" (click)="logout()">Log out</button>
            }
          </div>
        </div>
      }

      <!-- Edit form — signal-driven (no ngModel for name/email, uses signal) -->
      @if (editing()) {
        <form class="form" (ngSubmit)="save()">
          <div class="row">
            <label>Name *</label>
            <input [value]="editName()" (input)="editName.set($any($event.target).value)" placeholder="Your name"/>
          </div>
          <div class="row">
            <label>Email</label>
            <input type="email" [value]="editEmail()" (input)="editEmail.set($any($event.target).value)" placeholder="you@example.com"/>
          </div>
          <div class="row">
            <label>Avatar</label>
            <div class="avatar-picker">
              @for (a of avatars; track a) {
                <button type="button" class="av-btn" [class.sel]="editAvatar()===a" (click)="editAvatar.set(a)">{{a}}</button>
              }
            </div>
          </div>
          <div class="form-actions">
            <button type="submit" class="btn btn-primary" [disabled]="!formValid()">Save</button>
            <button type="button" class="btn btn-secondary" (click)="editing.set(false)">Cancel</button>
          </div>
        </form>
      }

      <!-- Signal summary panel -->
      <div class="signals">
        <div class="sig-title">All shared signals (live)</div>
        @for (row of rows(); track row.k) {
          <div class="sig-row"><span class="sk">{{ row.k }}</span><span class="sv">{{ row.v }}</span></div>
        }
      </div>
    </div>
  `,
  styles: [`
    .card{background:var(--color-surface);border:1px solid var(--color-border);
      border-radius:var(--radius-lg);padding:2rem;max-width:560px;
      box-shadow:var(--shadow-md);display:flex;flex-direction:column;gap:1.25rem}
    h2{font-size:1.5rem;font-weight:700;margin-bottom:.3rem}
    .desc{font-size:.85rem;color:var(--color-muted);line-height:1.5}
    code{background:#f1f5f9;padding:.1em .3em;border-radius:4px;font-size:.8em}
    .live-box{display:flex;align-items:center;gap:1rem;padding:.9rem 1.25rem;
      background:linear-gradient(135deg,#eff6ff,#dbeafe);border:1px solid #bfdbfe;border-radius:var(--radius)}
    .live-label{font-size:.75rem;color:#3b82f6;font-weight:600;text-transform:uppercase;letter-spacing:.06em;flex:1}
    .live-val{font-size:2.25rem;font-weight:800;color:#2563eb;line-height:1;font-variant-numeric:tabular-nums}
    .live-sub{font-size:.8rem;color:#60a5fa}
    .profile-row{display:flex;align-items:center;gap:1.25rem;padding:1.25rem;
      background:#f8fafc;border:1px solid var(--color-border);border-radius:var(--radius)}
    .avatar-ring{font-size:3rem;width:68px;height:68px;border-radius:50%;background:#fff;
      border:2px solid var(--color-border);display:flex;align-items:center;justify-content:center;flex-shrink:0}
    .info{flex:1}
    .info h3{font-size:1.1rem;font-weight:700;margin-bottom:.2rem}
    .email{font-size:.85rem;color:var(--color-muted);margin-bottom:.35rem}
    .badge{font-size:.72rem;font-weight:600;padding:.15rem .55rem;border-radius:999px;background:#f1f5f9;color:var(--color-muted)}
    .badge.on{background:#dcfce7;color:#15803d}
    .pactions{display:flex;flex-direction:column;gap:.5rem}
    .form{display:flex;flex-direction:column;gap:.9rem;padding:1.25rem;
      background:#fafafa;border:1px solid var(--color-border);border-radius:var(--radius)}
    .row{display:flex;flex-direction:column;gap:.3rem}
    .row label{font-size:.8rem;font-weight:600}
    .row input{padding:.5rem .75rem;border:1px solid var(--color-border);border-radius:var(--radius);
      font-size:.9rem;outline:none;transition:border-color .15s}
    .row input:focus{border-color:var(--color-primary)}
    .avatar-picker{display:flex;gap:.4rem;flex-wrap:wrap}
    .av-btn{font-size:1.4rem;width:44px;height:44px;border:2px solid var(--color-border);
      border-radius:var(--radius);background:#fff;cursor:pointer;transition:border-color .15s,transform .1s}
    .av-btn:hover{border-color:var(--color-primary)}
    .av-btn.sel{border-color:var(--color-primary);background:#eff6ff;transform:scale(1.1)}
    .form-actions{display:flex;gap:.75rem}
    .signals{border:1px solid var(--color-border);border-radius:var(--radius);overflow:hidden}
    .sig-title{font-size:.75rem;font-weight:600;text-transform:uppercase;letter-spacing:.06em;
      color:var(--color-muted);padding:.55rem .9rem;background:#f8fafc;border-bottom:1px solid var(--color-border)}
    .sig-row{display:flex;justify-content:space-between;padding:.4rem .9rem;
      font-size:.82rem;border-bottom:1px solid #f1f5f9}
    .sig-row:last-child{border-bottom:none}
    .sk{color:var(--color-muted);font-family:monospace}
    .sv{font-weight:600;color:var(--color-primary)}
  `]
})
export class UserProfileComponent {
  protected readonly s = inject(SharedStateService);
  protected readonly editing  = signal(false);
  protected readonly avatars  = AVATARS;
  protected readonly editName   = signal('');
  protected readonly editEmail  = signal('');
  protected readonly editAvatar = signal<string>('👤');
  protected readonly formValid  = computed(() => this.editName().trim().length > 0);

  // Drive the summary table from computed to avoid template logic
  protected readonly rows = computed(() => [
    { k: 'count',            v: String(this.s.count()) },
    { k: 'doubleCount',      v: String(this.s.doubleCount()) },
    { k: 'user.name',        v: this.s.user().name },
    { k: 'user.avatar',      v: this.s.user().avatar },
    { k: 'greeting',         v: this.s.greeting() },
    { k: 'isLoggedIn',       v: String(this.s.isLoggedIn()) },
    { k: 'lastAction',       v: this.s.lastAction() },
  ]);

  protected startEdit(): void {
    const u = this.s.user();
    this.editName.set(u.name); this.editEmail.set(u.email); this.editAvatar.set(u.avatar);
    this.editing.set(true);
  }

  protected save(): void {
    if (!this.formValid()) return;
    this.s.setUser({ name: this.editName().trim(), email: this.editEmail().trim(), avatar: this.editAvatar() });
    this.editing.set(false);
  }

  protected logout(): void { this.s.setUser({ name: 'Guest', email: '', avatar: '👤' }); }
}
