import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
@Component({ selector: 'mfe2-root', standalone: true, imports: [RouterOutlet],
  template: `<header style="padding:.5rem 1.5rem;background:#1e293b;color:#94a3b8;font-size:.8rem;display:flex;justify-content:space-between">
    <span>👤 MFE2 — User Profile</span><span style="font-style:italic;color:#475569">standalone dev mode</span>
  </header><main style="padding:2rem"><router-outlet /></main>` })
export class AppComponent {}
